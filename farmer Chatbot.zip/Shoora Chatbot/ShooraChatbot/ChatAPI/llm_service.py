from .models import ChatBotModel
from .gemini_client import get_gemini_response

def get_db_answer(query: str):
    try:
        obj = ChatBotModel.objects.get(question__iexact=query)
        return obj.bot_answer
    except ChatBotModel.DoesNotExist:
        return None


def get_custom_answer(query: str):
    # Step 1 → Check DB
    db_answer = get_db_answer(query)
    if db_answer:
        return db_answer

    # Step 2 → Gemini fallback with Shoora AI context
    custom_prompt = f"""
    You are a chatbot for FarmersAI organization.
    Farmer AI is a Farmer safety & tracking platform.


    User asked: {query}
    """
    return get_gemini_response(custom_prompt)
