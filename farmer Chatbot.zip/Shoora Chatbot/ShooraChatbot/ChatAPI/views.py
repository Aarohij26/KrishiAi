from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import ChatBotModel, ChatHistory
from .llm_service import get_custom_answer
from .serializers import ChatBotSerializers

class ChatBotAPIView(APIView):

    def get_client_ip(self, request):   
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for: 
            ip = x_forwarded_for.split(',')[0] 
        else: 
            ip = request.META.get('REMOTE_ADDR') 
        return ip

    def post(self, request):
        question = request.data.get("question")
        user = request.user if request.user.is_authenticated else None  

        if not question:
            return Response({"error": "Please provide a question"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            obj = ChatBotModel.objects.get(question__iexact=question) 
            answer = obj.answer
        except ChatBotModel.DoesNotExist:
            answer = get_custom_answer(question)

        ip = self.get_client_ip(request)
        history, created = ChatHistory.objects.update_or_create(
            user_query=question,
            defaults={"bot_answer": answer, "user_ip": ip} 
        )

        if not created: 
            history.count += 1 
            history.save()

        return Response(
            {"question": question, "answer": answer},
            status=status.HTTP_200_OK
        )
    


class ChatBotModelAPIView(APIView):
    def post(self, request):
        try:    
            serializer = ChatBotSerializers(data=request.data)

            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_200_OK)
            
            return Response(serializer.error, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e: 
            return Response( 
                {"Error": f'Something went wrong! {e}'}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR 
            )
