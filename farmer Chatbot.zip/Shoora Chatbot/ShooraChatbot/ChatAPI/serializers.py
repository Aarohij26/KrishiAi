from rest_framework import serializers
from .models import ChatBotModel

class ChatBotSerializers(serializers.ModelSerializer):
    class Meta:
        model = ChatBotModel
        fields = '__all__'

    def validate_question(self,value):
        return value.lower()