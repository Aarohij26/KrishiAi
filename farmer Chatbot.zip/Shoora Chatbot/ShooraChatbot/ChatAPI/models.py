from django.db import models
from uuid import uuid4

# Create your models here.

class ChatBotModel(models.Model):
    uuid = models.UUIDField(default=uuid4, unique=True, editable=False, verbose_name="UUID")
    question = models.TextField(unique=True)
    answer = models.TextField()

    def __str__(self):
        return self.question
    

class ChatHistory(models.Model):
    uuid = models.UUIDField(default=uuid4, unique=True, editable=True, verbose_name="UUID")
    user_query = models.TextField()
    user_ip = models.GenericIPAddressField(null=True, blank=True)
    bot_answer = models.TextField()
    count = models.PositiveIntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user_query (self.user_ip)}"