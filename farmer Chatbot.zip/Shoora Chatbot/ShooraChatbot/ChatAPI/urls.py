from django.contrib import admin
from django.urls import path
from .views import ChatBotAPIView, ChatBotModelAPIView

urlpatterns = [
    path('chatbot/', ChatBotAPIView.as_view(), name='chatbot' ),
    path('chatbot_model/', ChatBotModelAPIView.as_view(), name='chatbot_model'),
]
